from controller import Controller
from quadrotor import Quadrotor3D
from rclpy.node import Node
import rclpy
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy, DurabilityPolicy
from sensor_msgs.msg import Imu

# Define the initial state
current = [
    0.10475517809391, -0.017290910705924, 0.577277362346649,
    0.999788224697113, 0.00725210690870881, -0.00358528760261834,
    0.0189208406955004, -0.0283243507146835, -0.0150821516290307,
    0.0406060479581356, -0.00015171043924056, 6.65645929984748E-05,
    -0.000238538603298366
]

class DummyNode(Node):
    def __init__(self):
        super().__init__('dummy')  # Correctly initialize the Node
        self.iter = 0
        self.quad = None
        self.controller = None
        self.timer = self.create_timer(0.01, self.func)

        # Define subscription
        self.dummy_sub = self.create_subscription(
            Imu,
            "/dummy",
            self.callback,
            QoSProfile(
                reliability=ReliabilityPolicy.BEST_EFFORT,
                durability=DurabilityPolicy.TRANSIENT_LOCAL,
                history=HistoryPolicy.KEEP_LAST,
                depth=1
            )
        )

    def func(self):
        if self.iter == 0:
            # Initialize the quadrotor and controller
            self.quad = Quadrotor3D()
            self.controller = Controller(
                self.quad,
                t_horizon=20,
                n_nodes=100,
                initial_state=current
            )
            self.iter += 1
            self.get_logger().info("Quadrotor and Controller initialized.")
        else:
            # Adjust goal and run optimization
            a = current[2] - 1  # Adjusted z-coordinate
            goal = [current[0], current[1], a]
            thrust = self.controller.run_optimization(
                initial_state=current,
                goal=goal,
                use_model=0
            )[0:4]
            self.get_logger().info(f'Thrust: {thrust}')

    def callback(self, msg):
        self.get_logger().info("Received IMU message.")

if __name__ == "__main__":
    rclpy.init()
    node = DummyNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()
