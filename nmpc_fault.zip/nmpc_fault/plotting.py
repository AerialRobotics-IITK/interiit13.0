import pandas as pd
import matplotlib.pyplot as plt

# Read the CSV file
file_path = 'broken.csv'  # Replace with your CSV file path
file_path1 = 'data_mavros1.csv'  # Replace with your CSV file path
data = pd.read_csv(file_path)
data1 = pd.read_csv(file_path1)

# Display the first few rows to understand the structure
# print(data.head())

# Plot the data
# Assuming the CSV has columns 'X' and 'Y' for the plot
x_column = 'time'  # Replace with the column name for the x-axis
# y_column = 'Thrust 1'  # Replace with the column name for the y-axis

plt.figure(figsize=(10, 6))
# plt.plot(data["pos_x"][:60], label=f'{"pos_x"} vs {x_column}', marker='o')
# plt.plot(data["pos_y"][:60], label=f'{"pos_y"} vs {x_column}', marker='o')
# plt.plot(data["pos_z"][:60], label=f'{"pos_z"} vs {x_column}', marker='o')

# plt.plot(data["ang_vel_x"][:60], label=f'{"ang_x"} vs {x_column}', marker='o')
# plt.plot(data["ang_vel_y"][:60], label=f'{"ang_y"} vs {x_column}', marker='o')
# plt.plot(data["ang_vel_z"][:60], label=f'{"ang_z"} vs {x_column}', marker='o')

# plt.plot(data["q_w"][:60], label=f'{"qw"} vs {x_column}', marker='o')
# plt.plot(data["q_x"][:60], label=f'{"qx"} vs {x_column}', marker='o')
# plt.plot(data["q_y"][:60], label=f'{"qy"} vs {x_column}', marker='o')
# plt.plot(data["q_z"][:60], label=f'{"qz"} vs {x_column}', marker='o')


plt.plot(data["t1"][:60], label=f'{"t1"} vs {x_column}', marker='o')
plt.plot(data["t2"][:60], label=f'{"t2"} vs {x_column}', marker='o')
plt.plot(data["t3"][:60], label=f'{"t3"} vs {x_column}', marker='o')
plt.plot(data["t4"][:60], label=f'{"t4"} vs {x_column}', marker='o')

# plt.plot(data[x_column], data["x"], label=f'{"x"} vs {x_column}', marker='o')
# plt.plot(data[x_column], data["y"], label=f'{"y"} vs {x_column}', marker='o')
# plt.plot(data[x_column], data["z"], label=f'{"z"} vs {x_column}', marker='o')
# plt.plot(data[x_column], data1["x"], label=f'{"x1"} vs {x_column}', marker='o')
# plt.plot(data[x_column], data1["y"], label=f'{"y1"} vs {x_column}', marker='o')
# plt.plot(data[x_column], data1["z"], label=f'{"z1"} vs {x_column}', marker='o')

# plt.plot(data[x_column], data["Thrust 1"], label=f'{"Thrust 1"} vs {x_column}', marker='o')
# plt.plot(data[x_column], data["Thrust 2"], label=f'{"Thrust 2"} vs {x_column}', marker='o')
# plt.plot(data[x_column], data["Thrust 3"], label=f'{"Thrust 3"} vs {x_column}', marker='o')

# Customize the plot
plt.title('Plot from CSV Data')
plt.xlabel(x_column)
# plt.ylabel(y_column)
plt.legend()
plt.grid(True)

# Save or display the plot
# plt.savefig('plot_from_csv.png')  # Save the plot as a PNG file
plt.show()  # Display the plot
