import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
# Read the CSV file
file_path = 'check_indi.csv'  # Replace with your CSV file path
# file_path1 = 'data_mavros1.csv'  # Replace with your CSV file path
data = pd.read_csv(file_path)

# Display the first few rows to understand the structure
# print(data.head())

# Plot the data
# Assuming the CSV has columns 'X' and 'Y' for the plot
x_column = 'time'  # Replace with the column name for the x-axis
# y_column = 'Thrust 1'  # Replace with the column name for the y-axis

plt.figure(figsize=(10, 6))

# print(data.shape)
# print(data.iloc[0,17])
# plts_x=[]
# plts_y=[]
# plts_z=[]
# for i in range(1,249):
#     print(i)
#     print(data.iloc[i, 0])
#     print(data.iloc[i-1, 0])
#     print(data.iloc[i, 0]-data.iloc[i-1, 0])
#     plts_x+=[(data.iloc[i, 9] - data.iloc[i-1,9+30])]
# plt.plot(plts_x)
# plt.show()

# for i in range(200,290):
#     row = i
#     print(row)
#     column_indices = np.array(list(range(17, data.shape[1], 13))) #select one window

#     plt.plot(data.iloc[row, column_indices].values, label=f'{"pos_x"} vs {x_column}') 
#     plt.plot(data.iloc[row, column_indices+1].values, label=f'{"pos_y"} vs {x_column}')
#     plt.plot(data.iloc[row, column_indices+2].values, label=f'{"pos_z"} vs {x_column}')

#     #plt.plot(data.iloc[row, column_indices+10].values, label=f'{"ang_pos_x"} vs {x_column}')
#     #plt.plot(data.iloc[row, column_indices+11].values, label=f'{"ang_pos_y"} vs {x_column}')
#     #plt.plot(data.iloc[row, column_indices+12].values, label=f'{"ang_pos_z"} vs {x_column}')

#     plt.title('Plot from CSV Data')
#     plt.xlabel(x_column)
#     # plt.ylabel(y_column)
#     plt.legend()
#     plt.grid(True)
#     plt.show()

# plt.plot(data["pos_x"], label=f'{"osos_x"} vs {x_column}')
# plt.plot(data["pos_y"], label=f'{"pooss_y"} vs {x_column}')
# plt.plot(data["pos_z"], label=f'{"pos_osz"} vs {x_column}')

# #plt.plot(data["goal_x"], label=f'{"goal_x"} vs {x_column}')
# #plt.plot(data["goal_y"], label=f'{"goal_y"} vs {x_column}')
# #plt.plot(data["goal_z"], label=f'{"goal_z"} vs {x_column}')

# plt.title('Plot from CSV Data')
# plt.xlabel(x_column)
# # plt.ylabel(y_column)
# plt.legend()
# plt.grid(True)

# plt.show()  # Display the plot
plt.plot(data["indi_thrust1"], label=f'{"indi_thrust1"} vs {x_column}')
plt.plot(data["indi_thrust2"], label=f'{"indi_thrust2"} vs {x_column}')
plt.plot(data["indi_thrust3"], label=f'{"indi_thrust3"} vs {x_column}')
plt.plot(data["indi_thrust4"], label=f'{"indi_thrust4"} vs {x_column}')

plt.plot(data["actual_thrust1"], label=f'{"actual_thrust1"} vs {x_column}')
plt.plot(data["actual_thrust2"], label=f'{"actual_thrust2"} vs {x_column}')
plt.plot(data["actual_thrust3"], label=f'{"actual_thrust3"} vs {x_column}')
plt.plot(data["actual_thrust4"], label=f'{"actual_thrust4"} vs {x_column}')

plt.title('Comparing Indi')
plt.xlabel(x_column)
# plt.ylabel(y_column)
plt.legend()
plt.grid(True)

# plt.plot(data["traj_pos_x"], label=f'{"traj_pos_x"} vs {x_column}')
# plt.plot(data["tra_pos_y"], label=f'{"traj_pos_y"} vs {x_column}')
# plt.plot(data["traj_pos_z"], label=f'{"traj_pos_z"} vs {x_column}')

# plt.title('Trajectory')
# plt.xlabel(x_column)
# # plt.ylabel(y_column)
# plt.legend()
# plt.grid(True)

# plt.plot(data["ideal_pos_x"], label=f'{"ideal_x"} vs {x_column}')
# plt.plot(data["ideal_pos_y"], label=f'{"ideal_y"} vs {x_column}')
# plt.plot(data["ideal_pos_z"], label=f'{"ideal_z"} vs {x_column}')

# plt.plot(data["actual_pos_x"], label=f'{"actual_x"} vs {x_column}')
# plt.plot(data["actual_pos_y"], label=f'{"actual_y"} vs {x_column}')
# plt.plot(data["actual_pos_z"], label=f'{"actual_z"} vs {x_column}')

# plt.title('Comparing Dynamics')
# plt.xlabel(x_column)
# # plt.ylabel(y_column)
# plt.legend()
# plt.grid(True)

plt.show()  # Display the plot

exit(1)

# plt.plot(data["goal_x"], label=f'{"goal_x"} vs {x_column}')
# plt.plot(data["goal_y"], label=f'{"goal_y"} vs {x_column}')
# plt.plot(data["goal_z"], label=f'{"goal_z"} vs {x_column}')





plt.plot(data["ang_vel_x"][170:270], label=f'{"ang_x"} vs {x_column}')
plt.plot(data["ang_vel_y"][170:270], label=f'{"ang_y"} vs {x_column}')
plt.plot(data["ang_vel_z"][170:270], label=f'{"ang_z"} vs {x_column}')

plt.title('Plot from CSV Data')
plt.xlabel(x_column)
# plt.ylabel(y_column)
plt.legend()
plt.grid(True)

plt.show()  # Display the plot


plt.plot(data["q_w"], label=f'{"qw"} vs {x_column}')
plt.plot(data["q_x"], label=f'{"qx"} vs {x_column}')
plt.plot(data["q_y"], label=f'{"qy"} vs {x_column}')
plt.plot(data["q_z"], label=f'{"qz"} vs {x_column}')

plt.title('Plot from CSV Data')
plt.xlabel(x_column)
# plt.ylabel(y_column)
plt.legend()
plt.grid(True)

plt.show()  # Display the plot

plt.plot(data["t1"][170:270], label=f'{"t1"} vs {x_column}')
plt.plot(data["t2"][170:270], label=f'{"t2"} vs {x_column}')
plt.plot(data["t3"][170:270], label=f'{"t3"} vs {x_column}')
plt.plot(data["t4"][170:270], label=f'{"t4"} vs {x_column}')

# plt.plot(data["at1"][170:270], label=f'{"at1"} vs {x_column}')
# plt.plot(data["at2"][170:270], label=f'{"at2"} vs {x_column}')
# plt.plot(data["at3"][170:270], label=f'{"at3"} vs {x_column}')
# plt.plot(data["at4"][170:270], label=f'{"at4"} vs {x_column}')

plt.title('Plot from CSV Data')
plt.xlabel(x_column)
# plt.ylabel(y_column)
plt.legend()
plt.grid(True)

plt.show()  # Display the plot
# plt.plot(data[x_column], data["x"], label=f'{"x"} vs {x_column}')
# plt.plot(data[x_column], data["y"], label=f'{"y"} vs {x_column}')
# plt.plot(data[x_column], data["z"], label=f'{"z"} vs {x_column}')
# plt.plot(data[x_column], data1["x"], label=f'{"x1"} vs {x_column}')
# plt.plot(data[x_column], data1["y"], label=f'{"y1"} vs {x_column}')
# plt.plot(data[x_column], data1["z"], label=f'{"z1"} vs {x_column}')

# plt.plot(data[x_column], data["Thrust 1"], label=f'{"Thrust 1"} vs {x_column}')
# plt.plot(data[x_column], data["Thrust 2"], label=f'{"Thrust 2"} vs {x_column}')
# plt.plot(data[x_column], data["Thrust 3"], label=f'{"Thrust 3"} vs {x_column}')

# # Customize the plot
# plt.title('Plot from CSV Data')
# plt.xlabel(x_column)
# # plt.ylabel(y_column)
# plt.legend()
# plt.grid(True)

# plt.show()  # Display the plot
