import numpy as np
import matplotlib.pyplot as plt
from indi import Butterworth2LowPass as filter

a = np.linspace(1, 100)
sina = np.sin(a)

F = filter()
F.init(tau = 0.1, sample_time = 0.01, value = 1)

b = []
for i in range(len(a)):
    b.append(F.update(a[i]))

plt.plot(a, sina)
plt.show()
plt.plot(a, b)
plt.show()