from math import sqrt
import numpy as np
from utils import quaternion_to_euler, skew_symmetric, v_dot_q, unit_quat, quaternion_inverse

class Quadrotor3D:
    def __init__(self, drag=False, motor_noise=False):
        """Initialize the Quadrotor3D class with options for drag and motor noise."""

        # Parameters in SI Units
        self.max_rot_vel = 1000.0
        self.motor_const = 17.091776e-06 #motor constant in sdf file

##################################
        self.max_thrust = 14.528009599999999   # maximum thrust
        self.k_1000 = 17.091776e-03
##################################


        # self.J = np.array([0.033555106642101415, 0.033555106642101415, 0.06387979708741934])  # moment of inertia of quadrotor
        
        
        
        self.J = np.array([0.02361518496,
                           0.02371810977,
                           0.04399995371])  # moment of inertia of quadrotor
        
        # self.J = np.array([0.02166666666666667,
        #                    0.02166666666666667,
        #                    0.04000000000000001])  # moment of inertia of quadrotor
        
        self.mass = 2.064307692 # Mass of Quadrotor
        self.length = 0.174 # half of the full arm length
        self.c = 0.016  # z-torque constant for motors

        # Input constraints
        self.max_input_value = 1
        self.min_input_value = 0

        # Initialize state
        self.pos = np.array([0, 0, -0.5])
        self.vel = np.array([0, 0, 0])
        self.angle = np.array([1., 0., 0., 0.])
        self.a_rate = np.zeros(3)

        # Motor configurations for thrust torques
        h = self.length 
        self.y_f  = np.array([-h, h, h, -h])
        self.x_f = np.array([h, -h, h, -h])
        self.z_l_tau = np.array([self.c, -self.c, self.c, -self.c])

        # Gravity and disturbances
        self.g = np.array([[0], [0], [9.81]])
        self.u = np.zeros(4)
        self.drag = drag
        self.motor_noise = False

        # Drag coefficients
        self.rotor_drag_xy = 0.3
        self.rotor_drag_z = 0.0
        self.rotor_drag = np.array([self.rotor_drag_xy, self.rotor_drag_xy, self.rotor_drag_z])[:, np.newaxis]
        self.aero_drag = 0.08

    def set_state(self, *args, **kwargs):
        """Set the state of the quadrotor based on positional, angular, velocity, and rate inputs."""
        if args:
            assert len(args) == 1 and len(args[0]) == 13
            self.pos[:], self.angle[:], self.vel[:], self.a_rate[:] = np.split(args[0], [3, 7, 10])
        else:
            self.pos, self.angle, self.vel, self.a_rate = kwargs["pos"], kwargs["angle"], kwargs["vel"], kwargs["rate"]

    def get_state(self, quaternion=False, stacked=True):
        """Retrieve the current state of the quadrotor in quaternion or Euler angle format, as specified."""
        angle = quaternion_to_euler(self.angle) if not quaternion else self.angle
        state = [self.pos, angle, self.vel, self.a_rate]
        if stacked:
            return np.concatenate([self.pos, angle, self.vel, self.a_rate])
        return state

    def get_control(self):
        """Get the current control inputs."""
        return self.u

    def update(self, u, dt):
        """Update the state variables based on thrust input and a timestep `dt`."""
        # print(u)
        u = u.reshape(4,)
        print(f"u_dynamics: {u}")
        print(self.max_thrust)
        self.u[:] = np.clip(u, self.min_input_value, self.max_input_value) * self.max_thrust

        print(f"thrust according to dynamics: {self.u}")

        # Generate disturbances if motor noise is enabled
        f_d = np.random.normal(0, 10 * dt, (3, 1)) if self.motor_noise else np.zeros((3, 1))
        t_d = np.random.normal(0, 10 * dt, (3, 1)) if self.motor_noise else np.zeros((3, 1))


        # print(f"f_d, t_d: {f_d}, {t_d}")
        
        # Runge-Kutta method for state update
        x = self.get_state(quaternion=True, stacked=False)
        print(f"x_dot: {self.f_pos(x)}")
        print(f"f_att: {self.f_att(x)}")
        print(f"x_double_dot: {self.f_vel(x, self.u)}")
        print(f"f_rate: {self.f_rate(x, self.u)}")

        k1 = [self.f_pos(x), self.f_att(x), self.f_vel(x, self.u), self.f_rate(x, self.u)]
        x_aux = [x[i] + dt / 2 * k1[i] for i in range(4)]
        k2 = [self.f_pos(x_aux), self.f_att(x_aux), self.f_vel(x_aux, self.u), self.f_rate(x_aux, self.u)]
        x_aux = [x[i] + dt / 2 * k2[i] for i in range(4)]
        k3 = [self.f_pos(x_aux), self.f_att(x_aux), self.f_vel(x_aux, self.u), self.f_rate(x_aux, self.u)]
        x_aux = [x[i] + dt * k3[i] for i in range(4)]
        k4 = [self.f_pos(x_aux), self.f_att(x_aux), self.f_vel(x_aux, self.u), self.f_rate(x_aux, self.u)]

        self.pos, self.angle, self.vel, self.a_rate = [x[i] + dt * (1/6 * (k1[i] + 2*k2[i] + 2*k3[i] + k4[i])) for i in range(4)]

        # print(f"\nPosition according to Dynamics: {self.pos}")
        
        self.angle = unit_quat(self.angle)

    def f_pos(self, x):
        """Calculate positional change rate based on current velocity."""
        return x[2]

    def f_att(self, x):
        """Calculate rate of change of attitude based on angular rates."""
        return 0.5 * skew_symmetric(x[3]).dot(x[1])

    def f_vel(self, x, u):
        """Calculate the acceleration based on thrust, gravity, and drag (if enabled)."""
        print(f"u in f_vel: {u}")
        # print(f"cumulative thrust: {np.sum(u)}")
        # print(f"thrust added: {u[0] + u[1] + u[2] + u[3]}")
        a_thrust = np.array([[0], [0], [np.sum(u)]]) / self.mass
        print(f"a_thrust: {a_thrust}")
        print(f"gravity: {self.g}")
        # print(f"quaternion: {x[1]}")
        # print(f"resultant: {np.squeeze(self.g + v_dot_q(a_thrust, x[1]))}")
        return np.squeeze(self.g - v_dot_q(a_thrust, x[1]))

    def f_rate(self, x, u):
        """Calculate angular acceleration based on torques generated by thrust and any disturbances."""
        rate = x[3]
        return np.array([
            (u.dot(self.y_f)     + (self.J[1] - self.J[2]) * rate[1] * rate[2]) / self.J[0],
            (u.dot(self.x_f)     + (self.J[2] - self.J[0]) * rate[2] * rate[0]) / self.J[1],
            (u.dot(self.z_l_tau) + (self.J[0] - self.J[1]) * rate[0] * rate[1]) / self.J[2]
        ]).squeeze()

