from quadrotor import Quadrotor3D
from controller_with_2 import Controller

initial_state=[]
quad = Quadrotor3D()
controller2 = Controller(quad, t_horizon=1, n_nodes=20, initial_state=initial_state, broken=True, model_name='broken')

thrust, x_opt = controller2.run_optimization(initial_state=initial_state, goal=[-0.26663396, 0.15839522, 0.34225884-5], use_model=0)