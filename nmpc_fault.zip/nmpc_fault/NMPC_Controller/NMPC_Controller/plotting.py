import numpy as np
import matplotlib.pyplot as plt

from quadrotor import Quad

class PlotQuad:
    def __init__(self):
        pass 
    
    def plotTrajectory(quad:Quad):
        pass